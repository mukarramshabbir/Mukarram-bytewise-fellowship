//
//  Generated file. Do not edit.
//

// clang-format off

#import "GeneratedPluginRegistrant.h"

#if __has_include(<camera_avfoundation/CameraPlugin.h>)
#import <camera_avfoundation/CameraPlugin.h>
#else
@import camera_avfoundation;
#endif

#if __has_include(<file_picker_writable/FilePickerWritablePlugin.h>)
#import <file_picker_writable/FilePickerWritablePlugin.h>
#else
@import file_picker_writable;
#endif

#if __has_include(<file_selector_ios/FFSFileSelectorPlugin.h>)
#import <file_selector_ios/FFSFileSelectorPlugin.h>
#else
@import file_selector_ios;
#endif

#if __has_include(<flutter_document_scan_sdk/FlutterDocumentScanSdkPlugin.h>)
#import <flutter_document_scan_sdk/FlutterDocumentScanSdkPlugin.h>
#else
@import flutter_document_scan_sdk;
#endif

#if __has_include(<flutter_exif_rotation/FlutterExifRotationPlugin.h>)
#import <flutter_exif_rotation/FlutterExifRotationPlugin.h>
#else
@import flutter_exif_rotation;
#endif

#if __has_include(<image_picker_ios/FLTImagePickerPlugin.h>)
#import <image_picker_ios/FLTImagePickerPlugin.h>
#else
@import image_picker_ios;
#endif

#if __has_include(<path_provider_foundation/PathProviderPlugin.h>)
#import <path_provider_foundation/PathProviderPlugin.h>
#else
@import path_provider_foundation;
#endif

#if __has_include(<permission_handler_apple/PermissionHandlerPlugin.h>)
#import <permission_handler_apple/PermissionHandlerPlugin.h>
#else
@import permission_handler_apple;
#endif

#if __has_include(<printing/PrintingPlugin.h>)
#import <printing/PrintingPlugin.h>
#else
@import printing;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [CameraPlugin registerWithRegistrar:[registry registrarForPlugin:@"CameraPlugin"]];
  [FilePickerWritablePlugin registerWithRegistrar:[registry registrarForPlugin:@"FilePickerWritablePlugin"]];
  [FFSFileSelectorPlugin registerWithRegistrar:[registry registrarForPlugin:@"FFSFileSelectorPlugin"]];
  [FlutterDocumentScanSdkPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterDocumentScanSdkPlugin"]];
  [FlutterExifRotationPlugin registerWithRegistrar:[registry registrarForPlugin:@"FlutterExifRotationPlugin"]];
  [FLTImagePickerPlugin registerWithRegistrar:[registry registrarForPlugin:@"FLTImagePickerPlugin"]];
  [PathProviderPlugin registerWithRegistrar:[registry registrarForPlugin:@"PathProviderPlugin"]];
  [PermissionHandlerPlugin registerWithRegistrar:[registry registrarForPlugin:@"PermissionHandlerPlugin"]];
  [PrintingPlugin registerWithRegistrar:[registry registrarForPlugin:@"PrintingPlugin"]];
}

@end
