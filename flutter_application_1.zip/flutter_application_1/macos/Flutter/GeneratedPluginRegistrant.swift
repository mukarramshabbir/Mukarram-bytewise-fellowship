//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import file_picker_writable
import file_selector_macos
import path_provider_foundation
import printing

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  FilePickerWritablePlugin.register(with: registry.registrar(forPlugin: "FilePickerWritablePlugin"))
  FileSelectorPlugin.register(with: registry.registrar(forPlugin: "FileSelectorPlugin"))
  PathProviderPlugin.register(with: registry.registrar(forPlugin: "PathProviderPlugin"))
  PrintingPlugin.register(with: registry.registrar(forPlugin: "PrintingPlugin"))
}
