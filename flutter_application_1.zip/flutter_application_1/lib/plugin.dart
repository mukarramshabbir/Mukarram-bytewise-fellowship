import 'package:flutter_document_scan_sdk/flutter_document_scan_sdk.dart';

final flutterDocumentScanSdkPlugin = FlutterDocumentScanSdk();
int NOT_CHECKED = -10;
int licenseStatus = NOT_CHECKED;
